const express = require('express');
const AllEventsAutomation = require('./AllEvents');
const app = express();

app.use(express.json());

const automation = new AllEventsAutomation();

app.post('/login', async (req, res) => {
    const { email, password } = req.body;
    try {
        await automation.initialize();
        const message = await automation.login(email, password);
        res.json({ message });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/logout', async (req, res) => {
    try {
        const message = await automation.logout();
        await automation.close();
        res.json({ message });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/createEvent', async (req, res) => {
    const {name, startdate, starttime,enddate,endtime, description} = req.body;
    try {
        const message = await automation.createEvent(name, startdate, starttime,enddate,endtime, description);
        res.json({ message });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

app.post('/searchHashtags', async (req, res) => {
    const { hashtag ,location} = req.body;
    try {
        const events = await automation.searchHashtags(hashtag,location);
        res.json(events);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});
