const puppeteer = require('puppeteer');

class AllEventsAutomation {
    constructor() {
        this.browser = null;
        this.page = null;
    }

    
    async initialize() {
        try {
            this.browser = await puppeteer.launch({
                headless: false,
                executablePath: 'C:/Program Files/Google/Chrome/Application/chrome.exe', // Use installed Chrome
                defaultViewport: { width: 1920, height: 1080 }
            });
            this.page = await this.browser.newPage();
            console.log('Browser initialized successfully.');
        } catch (error) {
            console.error('Failed to initialize browser:', error);
            if (this.browser) await this.browser.close();
        }
    }
    async login(email, password) {
        if(!this.page){console.error("initialize page first");}
        try {
            await this.page.goto('https://www.allevents.in/events');
            await this.page.click('#login-top');
            await this.page.waitForSelector('#login-option-email', { visible: true });

            // Click the button
            await this.page.click('#login-option-email');

            // Fill in email
            await this.page.waitForSelector('#inputEmail');
            await this.page.type('#inputEmail', email);
            await this.page.click('#existance_lookup_btn');
            // await this.page.waitForNavigation();

            // Wait for the password field and type the password
            await this.page.waitForSelector('input[type="password"]', { visible: true });
            await this.page.type('input[type="password"]', password);

            // Click the
            await this.page.click('#signin_with_email_btn'); // Adjust selector if needed

            // Wait for navigation
            await this.page.waitForNavigation();
            return 'Login successful';
        } catch (error) {
            throw new Error(`Login failed: ${error.message}`);
        }
    }



    async logout() {
        try {
            await this.page.click('button.btn btn-inverse dropdown-toggle btn-topbar');
            await this.page.click('a[href="https://allevents.in/manage/logout.php?ref=topbar-dropdown"]'); // Replace with the actual logout button selector
            await this.page.waitForNavigation();
            return 'Logout successful';
        } catch (error) {
            throw new Error(`Logout failed: ${error.message}`);
        }
    }
    async createEvent(name, startdate, starttime, enddate, endtime, description) {
        try {
            // Wait for the "Create Event" button to appear and click it
            await this.page.waitForSelector('.btn.btn-inverse.create-action.track.popo.topbar-btn');
            await this.page.click('.btn.btn-inverse.create-action.track.popo.topbar-btn');

            console.log('Create Event button clicked!');
            await this.page.waitForSelector('#eventname');
            await this.page.type('#eventname', name);

            // Helper function to clear input fields
            const clearInput = async (selector) => {
                await this.page.click(selector); // Focus the input field
                const inputValue = await this.page.$eval(selector, el => el.value);
                for (let i = 0; i < inputValue.length; i++) {
                    await this.page.keyboard.press('Backspace');
                }
            };

            // Clear inputs and type new values
            await this.page.waitForSelector('input[name="start_date"]');
            await clearInput('input[name="start_date"]');
            await this.page.type('input[name="start_date"]', startdate);

            await this.page.waitForSelector('input[name="start_time"]');
            await clearInput('input[name="start_time"]');
            await this.page.type('input[name="start_time"]', starttime);

            await this.page.keyboard.press("Enter");

            await this.page.waitForSelector('input[name="end_date"]');
            await clearInput('input[name="end_date"]');
            await this.page.type('input[name="end_date"]', enddate);

            await this.page.waitForSelector('input[name="end_time"]');
            await clearInput('input[name="end_time"]');
            await this.page.type('input[name="end_time"]', endtime);

            // Wait for the dropdown element to be loaded
            await this.page.waitForSelector('.select2-container');

            // Click on the dropdown to open the options
            await this.page.click('.select2-container');

            // Wait for the options to load
            await this.page.waitForSelector('select#event_mode option', { timeout: 60000 });

            // Retrieve and log all available options
            const options = await this.page.$$eval('select#event_mode option', options =>
                options.map(option => ({
                    text: option.textContent.trim(),
                    value: option.value
                }))
            );

            console.log('Available options:', options);

            // Select the "Online" option
            await this.page.select('#event_mode', 'online'); // Use the `value` of the option to select it

            // Confirm the selection (optional)
            const selectedOption = await this.page.$eval('#event_mode', select => select.value);
            console.log('Selected option:', selectedOption);

            // Fill in the description and save the event
            await this.page.waitForSelector('#event_description_quilljs');
            await this.page.type('#event_description_quilljs', description);
            await this.page.click('#save-draft-btn');

            console.log('Event created successfully!');
            return 'Event created successfully';
        } catch (error) {
            throw new Error(`Create Event failed: ${error.message}`);
        }
    }

    async searchHashtags(hashtag, location) {
        try {
            // Wait for the hashtag input to be visible and type the hashtag
            await this.page.waitForSelector('#inputCat', { visible: true });
            await this.page.type('#inputCat', hashtag);

            // Wait for the location input to be visible and type the location
            await this.page.waitForSelector('#inputCity', { visible: true });
            await this.page.type('#inputCity', location);

            // Wait for the search button and click it
            await this.page.waitForSelector('.search-box .btn.btn-success.esearch-action.skyload');
            await this.page.click('.search-box .btn.btn-success.esearch-action.skyload');
            console.log('Search button clicked!');

            // Wait for the search results to load
            await this.page.waitForSelector('.event-card-parent li', { visible: true });

            // Extract event details
            const events = await this.page.evaluate(() => {
                const results = [];
                const eventCards = document.querySelectorAll('.event-card-parent li');

                eventCards.forEach(card => {
                    results.push({
                        title: card.querySelector('h3')?.innerText || 'No Title',
                        link: card.getAttribute('data-link') || 'No Link',
                        photoUrl: card.querySelector('div.banner-cont')?.getAttribute('style')?.match(/url\((.*?)\)/)?.[1] || 'No Photo',
                        dateTime: card.querySelector('div.date')?.innerText || 'No Date/Time',
                        location: card.querySelector('div.subtitle')?.innerText || 'No Location',
                        stars: card.querySelector('.interested-container ')?.innerText.match(/(\d+)/) || 'No Rating',
                        Totalprice:card.querySelector('.price-container')?.innerText.match(/CAD\s+(\d+)/) || '0',
                    });
                });

                return results;
            });

            // Return the extracted events
            console.log(`Extracted ${events.length} events`);
            return events;
        } catch (error) {
            throw new Error(`Search Hashtags failed: ${error.message}`);
        }
    }

    async close() {
        await this.browser.close();
    }
}

module.exports = AllEventsAutomation;
